inner.run <-
function(group, repeats, num_fold_cross_validation, max_parameter_limit, sample_size, num_fold_cross_validation_inner){

	samples_group=sample(group, sample_size, replace=FALSE)
	
	expression_matrix = X[,colnames(X) %in% samples_group]
	activity_matrix = Act[,colnames(Act) %in% samples_group]
	edgestrength_matrix = ES
	
	result_complete=c()
	result_complete_inner=c()
	predictions=c()
	table_complete=c()

	##### Options #####
	big_m = 1000

	b_bas = "b_bas"
	b_pre = "b_"
	x_pre = "x_"
	
	for (ll in 1:repeats){
	cat("Repeat", ll, "\n")
	
	########################## Sample set
	#select #num_sample_exclude samples randomly
	sample_pool = colnames(expression_matrix)
	num_sample_exclude = length(sample_pool) / num_fold_cross_validation
	num_sample_exclude = floor(num_sample_exclude)

	iteration_vector = c()
	sample_iteration_vector = c()

	iteration=0
	while(length(sample_pool) >= num_sample_exclude){
  		iteration = iteration + 1
  		iteration_vector = c(iteration_vector,iteration)
  
  		selected_samples = sample(sample_pool,num_sample_exclude, replace=FALSE)
  		selected_samples_term = paste(selected_samples, collapse = ",")
  		sample_iteration_vector = c(sample_iteration_vector,selected_samples_term)
  
  		selected_samples_index = which(sample_pool %in% selected_samples)
  		sample_pool = sample_pool[-selected_samples_index]  
	}

	iteration_sample_df = data.frame(iteration_vector,sample_iteration_vector)
	colnames(iteration_sample_df) = c("iteration","samples")
   
	#expression index
	target_gene_expression_index = which(rownames(expression_matrix) == target_gene)
  
  	#determine number of parameters
  	num_parameter = 0
  	num_exp_parameter = 0
  	num_cons_parameter = 0
  	num_error_terms = 0
  	parameter_limit = 0
  
  	constraint_matrix_colnames = c()
  	binary_parameters = c()  
  	exp_parameters = c()
  	tf_vector = c()
  
  	#b_bas
    num_parameter = num_parameter + 1
    constraint_matrix_colnames = c(constraint_matrix_colnames,b_bas) 

  	#TFs
    target_gene_tf_index = which(edgestrength_matrix[target_gene,] > 0)
    tf_vector = as.vector(colnames(edgestrength_matrix)[target_gene_tf_index])
      
      num_parameter = num_parameter + (2 * length(tf_vector))
      num_exp_parameter = num_exp_parameter + length(tf_vector)
      num_cons_parameter = num_cons_parameter + (2 * length(tf_vector))
      
      #construct b_tf and x_tf variables
      for(i in 1:length(tf_vector)){
        tf = tf_vector[i]        
        b_tf = paste("b_",tf,sep="")
        x_tf = paste("x_",tf,sep="")
        constraint_matrix_colnames = c(constraint_matrix_colnames,b_tf)
        constraint_matrix_colnames = c(constraint_matrix_colnames,x_tf)
        binary_parameters = c(binary_parameters,x_tf)
        exp_parameters = c(exp_parameters,b_tf)
      }      
    
    if(num_exp_parameter < max_parameter_limit){
    parameter_limit = num_exp_parameter
  }else{
    parameter_limit = max_parameter_limit
  }

###########################################################################  
  
  #iterate over all samples sets for cross validation
	
	
	for(q in 1:length(rownames(iteration_sample_df))){
    current_cross_validation = q
    
    cat("Cross-validation", q, "\n")
    
    result.table <- as.data.frame(cbind("TF"=1,"Betas_TF"=1,"Amount TF"=1, "correlation"=1))

    pred=matrix(nrow=num_sample_exclude, ncol=max_parameter_limit+1)
         
    current_predict_sample_term = as.character(iteration_sample_df[q,2])
    current_predict_samples = as.vector(strsplit(current_predict_sample_term,",")[[1]])
    
    #get training samples
    training_samples_index = which(!colnames(expression_matrix) %in% current_predict_samples)
    training_samples = as.vector(colnames(expression_matrix)[training_samples_index])
    
    ############# Start inner cross-validation ###################
    #select #num_sample_exclude samples randomly
	sample_pool_inner = training_samples
	num_sample_exclude_inner = length(sample_pool_inner) / num_fold_cross_validation_inner
	num_sample_exclude_inner = floor(num_sample_exclude_inner)

	iteration_vector_inner = c()
	sample_iteration_vector_inner = c()

	iteration=0
	while(length(sample_pool_inner) >= num_sample_exclude_inner){
  		iteration = iteration + 1
  		iteration_vector_inner = c(iteration_vector_inner,iteration)
  
  		selected_samples_inner = sample(sample_pool_inner,num_sample_exclude_inner, replace=FALSE)
  		selected_samples_term_inner = paste(selected_samples_inner, collapse = ",")
  		sample_iteration_vector_inner = c(sample_iteration_vector_inner,selected_samples_term_inner)
  
  		selected_samples_index_inner = which(sample_pool_inner %in% selected_samples_inner)
  		sample_pool_inner = sample_pool_inner[-selected_samples_index_inner]  
	}

	iteration_sample_df_inner = data.frame(iteration_vector_inner,sample_iteration_vector_inner)
	colnames(iteration_sample_df_inner) = c("iteration","samples")
   
    
    ############# End inner cross-validation #####################
    
    #construct global result matrix
    result_matrix_num_rows = parameter_limit
    result_matrix_num_cols = length(exp_parameters) + 1  
    result_parameter_matrix = matrix(0,result_matrix_num_rows,result_matrix_num_cols)
    colnames(result_parameter_matrix) = c("parameter_limit",exp_parameters)    
    parameter_limit_vector = as.vector(seq(1:parameter_limit))
    result_parameter_matrix[,"parameter_limit"] = parameter_limit_vector
    result_parameter_matrix = as.matrix(result_parameter_matrix)
    
    ###########################################################################  
    #set up model for all training samples
    
    #replace - by . in all samples
    current_model_samples = training_samples
    
    if (num_fold_cross_validation==1){
    current_model_samples=current_predict_samples
    }
    
    #determine which model samples have valid expression values
    current_model_sample_index = which(colnames(expression_matrix) %in% current_model_samples)
    reduced_expression_matrix = expression_matrix[,current_model_sample_index]
    reduced_activity_matrix = activity_matrix[,current_model_sample_index]
    
    current_model_sample_valid_expression_value_index = which(!is.na(reduced_expression_matrix[target_gene_expression_index,]))
    current_model_samples = as.vector(colnames(reduced_expression_matrix)[current_model_sample_valid_expression_value_index])    
    
    cat("Calculating inner cross-validation", "\n")
    ######################################################################################
 	# Run model from 1 to 10 TF combinations
        
    for(o in 1:parameter_limit){ 
      current_parameter_limit = as.numeric(o)
          
################### Inner CV ######################  
   result.table2 <- as.data.frame(cbind("TF"=1,"Betas_TF"=1,"Amount TF"=1, "correlation"=1))
 
    #construct global result matrix
    result_matrix_num_rows_inner = num_fold_cross_validation_inner
    result_matrix_num_cols_inner = length(exp_parameters) + 1  
    result_parameter_matrix_inner = matrix(0,result_matrix_num_rows_inner,result_matrix_num_cols_inner)
    colnames(result_parameter_matrix_inner) = c("number_parameters",exp_parameters)    
    parameter_limit_vector_inner = as.vector(rep(current_parameter_limit, num_fold_cross_validation_inner))
    result_parameter_matrix_inner[,"number_parameters"] = parameter_limit_vector_inner
    result_parameter_matrix_inner = as.matrix(result_parameter_matrix_inner)	
    
    for(qq in 1:length(rownames(iteration_sample_df_inner))){
    	current_cross_validation_inner = qq
           
    	current_predict_sample_term_inner = as.character(iteration_sample_df_inner[qq,2])
    	current_predict_samples_inner = as.vector(strsplit(current_predict_sample_term_inner,",")[[1]])
    
    	#get training samples
    	training_samples_index_inner = which(!colnames(reduced_expression_matrix) %in% current_predict_samples_inner)
    	training_samples_inner = as.vector(colnames(reduced_expression_matrix)[training_samples_index_inner])
  	
		#set up model for all training samples
    
    	current_model_samples_inner = training_samples_inner     
    
    	if (num_fold_cross_validation_inner==1){
    	current_model_samples_inner=current_predict_samples_inner
    	}
    
    	#determine which model samples have valid expressiron values
    	current_model_sample_index_inner = which(colnames(reduced_expression_matrix) %in% current_model_samples_inner)
    	reduced_expression_matrix_inner = reduced_expression_matrix[,current_model_sample_index_inner]
    
    	current_model_sample_valid_expression_value_index_inner = which(!is.na(reduced_expression_matrix_inner[target_gene_expression_index,]))
    	current_model_samples_inner = as.vector(colnames(reduced_expression_matrix_inner)[current_model_sample_valid_expression_value_index_inner])    
  		
  		current_model_matrix_colnames_inner = c(constraint_matrix_colnames)
    
   	 	#define error terms
    	for(i in 1:length(current_model_samples_inner)){
      		current_sample_inner = current_model_samples_inner[i]
      		sample_error_term_inner = paste("e_",current_sample_inner,sep="")
      		current_model_matrix_colnames_inner = c(current_model_matrix_colnames_inner,sample_error_term_inner)
    	}
    	num_error_terms_inner = length(current_model_samples_inner)
   
		num_constraints_inner = num_cons_parameter + (2 * length(current_model_samples_inner)) + 1    
    	total_column_number_inner = num_parameter + num_error_terms_inner   
    
    	###define model variables per iteration    
    	#right-hand-side
    	rhs = c()
    	#objective vector
    	obj = c()
   		#fill with num_parameter x 0
    	obj = c(obj,rep(0,total_column_number_inner))
    	#model sense
   		modelsense = "min"
    	#sense vector
   		sense = c()
    	#variable type
    	vtype = c(rep("C",total_column_number_inner))
    	#"C" (continuous), "B" (binary), "I" (integer), "S" (semi-continuous), or "N" (semi-integer)
    	#lower bound
   		lb = c(rep(0,total_column_number_inner))
    	#upper bound
    	ub = c(rep(0,total_column_number_inner))
   		#constraint matrix
    
    	B <- matrix(0,nrow=num_constraints_inner,ncol=total_column_number_inner,byrow=T)
    
    	colnames(B) = current_model_matrix_colnames_inner
    	names(obj) = current_model_matrix_colnames_inner
   		names(lb) = current_model_matrix_colnames_inner
    	names(ub) = current_model_matrix_colnames_inner
    	names(vtype) = current_model_matrix_colnames_inner
    	
    	#iterate over samples and create sample constraints
    	for(i in 1:length(current_model_samples_inner)){
      		current_sample_inner = current_model_samples_inner[i]
     		#create error term
     		sample_error_term_inner = paste("e_",current_sample_inner,sep="")
      		sample_error_term_index_inner = which(colnames(B) == sample_error_term_inner)
      		#add value to obj
      		sample_error_obj_index_inner = which(names(obj) == sample_error_term_inner)
      		obj[sample_error_obj_index_inner] = 1
      
      		#add lb
      		sample_error_lb_index_inner = which(names(lb) == sample_error_term_inner)
      		lb[sample_error_lb_index_inner] = 0
      
      		#add ub
     		 sample_error_ub_index_inner = which(names(ub) == sample_error_term_inner)
      		ub[sample_error_ub_index_inner] = big_m
      
      		#sample expression value
     		current_sample_expression_index_inner = which(colnames(expression_matrix) == current_sample_inner)
      		current_sample_expression_value_inner = as.numeric(expression_matrix[target_gene_expression_index,current_sample_expression_index_inner])
      		#print(current_sample_expression_value)
     		current_sample_expression_negative_value_inner = -(current_sample_expression_value_inner)
     		#add expression values (+ and -) to rhs vector
      		rhs = c(rhs,current_sample_expression_value_inner,current_sample_expression_negative_value_inner)
      		#add sense for each expression vector
     		sense = c(sense,"<=","<=")
      
      		#b_bas
        	#always 1
        	#add to constraint_matrix
        	B[((2*i)-1),b_bas] = 1
        	B[(2*i),b_bas] = -1
        
        	#add bounds
        	lb[b_bas] = -big_m
        	ub[b_bas] = big_m
      
      		#TF
        	if(length(tf_vector) > 0){
          	for(m in 1:length(tf_vector)){
            	tf = tf_vector[m]
                        
            	b_tf = paste(b_pre,tf,sep="")
            	x_tf = paste(x_pre,tf,sep="")
            
            	current_sample_tf_value_inner = 0
            
            	current_sample_tf_index_inner = which(colnames(activity_matrix) == current_sample_inner)
            	if(length(current_sample_tf_index_inner) > 0){
              		current_tf_index_inner = which(rownames(activity_matrix) == tf)
              	if(!is.na(activity_matrix[current_tf_index_inner,current_sample_tf_index_inner])){
                	current_sample_tf_value_inner = as.numeric(activity_matrix[current_tf_index_inner,current_sample_tf_index_inner])*edgestrength_matrix[which(rownames(edgestrength_matrix)==target_gene),which(colnames(edgestrength_matrix) == tf)]
              	}
            }           
            
            #add to constraint_matrix
            B[((2*i)-1),b_tf] = current_sample_tf_value_inner
            B[(2*i),b_tf] = -current_sample_tf_value_inner
            
            #add variable type                  
            vtype[x_tf] = "B"
            
            #add bounds          
            lb[b_tf] = -big_m
            ub[b_tf] = big_m
            
            lb[x_tf] = 0
            ub[x_tf] = 1
            
          }
        }      
      
		#add error terms
      	B[((2*i)-1),sample_error_term_index_inner] = -1
      	B[(2*i),sample_error_term_index_inner] = -1      
      
    	}
    
    	###########################################################
    	#determine current row_index
    	current_row_index_inner = (2 * length(current_model_samples_inner)) + 1
   	 	#add constraints
    
    	#TF
      	if(length(tf_vector) > 0){
        	for(m in 1:length(tf_vector)){
          		tf = tf_vector[m]
          
          		b_tf = paste(b_pre,tf,sep="")
          		x_tf = paste(x_pre,tf,sep="")
          
          		#add 1 for exp parameter
          		B[current_row_index_inner,b_tf] = 1
          		#add #big_m for binary parameter
          		B[current_row_index_inner,x_tf] = -big_m
          		current_row_index_inner = current_row_index_inner + 1
          		#repeat with minus sign
          		B[current_row_index_inner,b_tf] = 1
          		B[current_row_index_inner,x_tf] = big_m
          
          		sense = c(sense,"<=",">=")
          		rhs = c(rhs,0,0)
          
          		current_row_index_inner = current_row_index_inner + 1
        		} 
     	 }         
        
		#add constraint limit for all binary parameters
   		for(k in 1:length(binary_parameters)){
      		binary_parameter = binary_parameters[k]
      		binary_parameter_index = which(colnames(B) == binary_parameter)
      		B[current_row_index_inner,binary_parameter_index] = 1
    	}
    
    	#add sense to last row for parameter_limit
    	sense = c(sense,"<=")
   		
   		current_parameter_limit_inner = as.numeric(o)
      	#print(current_parameter_limit)      
      	current_result_parameter_index_inner = which(result_parameter_matrix_inner[,"number_parameters"] == current_parameter_limit_inner)
      	#last constraint : sum of all binary variable <= parameter_limit
      	#add current parameter_limit to rhs
      	rhs[current_row_index_inner] = current_parameter_limit_inner
      
      	model <- list()
      	model$A          <- B
     	model$obj        <- obj
     	model$modelsense <- modelsense
      	model$rhs        <- rhs
      	model$sense      <- sense
      	model$lb         <- lb
      	model$ub         <- ub
      	model$vtype      <- vtype
         
      	result <- gurobi(model, params)
     
     	#Evaluate single results
      
      	result_var_vector_inner = c()
      	result_value_vector_inner = c()
      
      	#find indices in current_model_matrix_colnames      
      
      	#TF
      	top_hits_inner=c()
      
     	 if(length(tf_vector) > 0){
          for(m in 1:length(tf_vector)){
            tf = tf_vector[m]
            
            b_tf = paste(b_pre,tf,sep="")
            x_tf = paste(x_pre,tf,sep="")
            
            b_index = which(current_model_matrix_colnames_inner == b_tf)
            b_value = as.numeric(result$x[b_index])
            
        	x_index = which(current_model_matrix_colnames_inner == x_tf)
            x_value = as.numeric(result$x[x_index])
            
            if(round(x_value,1) == 1){
              top_hits_inner=c(top_hits_inner, tf)
              result_var_vector_inner = c(result_var_vector_inner,b_tf)
              result_value_vector_inner = c(result_value_vector_inner,b_value)
              parameter_index_inner = which(colnames(result_parameter_matrix_inner) == b_tf)
              result_parameter_matrix_inner[qq,parameter_index_inner] = b_value
            }
          } 
        }           
       
       id.tf=which(colnames(ES) %in% top_hits_inner) 
     
       v=rep(0, num_fold_cross_validation_inner)
    
   	   if(qq==1){
       	   result_parameter_matrix2_inner=cbind(result_parameter_matrix_inner, v)
    	   colnames(result_parameter_matrix2_inner)[length(tf_vector)+2]="b_bas"
    	   result_parameter_matrix2_inner[qq,length(tf_vector)+2]=result$x[1]
       } else {result_parameter_matrix2_inner[qq,length(tf_vector)+2]=result$x[1]
    	   result_parameter_matrix2_inner[qq,1:(length(tf_vector)+1)]=result_parameter_matrix_inner[qq,]}
    	   
       #Run Estimation of Prediction Performance:
	
		beta.values_inner=result_parameter_matrix2_inner[qq,2:(length(tf_vector)+2)][result_parameter_matrix2_inner[qq,2:(length(tf_vector)+2)]!=0]
	
   	 	X_val_inner=reduced_expression_matrix[,colnames(reduced_expression_matrix) %in% current_predict_samples_inner]
  		Act_val_inner<-reduced_activity_matrix[,colnames(reduced_activity_matrix) %in% current_predict_samples_inner]
    
    	cell_line_name <- colnames(reduced_expression_matrix)
    	id.cellline <- c(1:length(colnames(reduced_expression_matrix)))
    	names(id.cellline) <- cell_line_name
    
    	g_real_all <- c()
    	prediction_all <- c()
    	cor.vector <- c()
	
    	id.gene.val <- id.cellline[names(id.cellline) %in% colnames(X_val_inner)] 
    	id.gene.test <- id.cellline[-(id.gene.val)]
  
  		g=which(rownames(edgestrength_matrix)==target_gene)     
  
    	###get real genexpression values for the remaining genes (validationset)
      	g_real_val <- c()
     
      	for(j in id.gene.val){
        	i = g
       		g_real_val <- c(g_real_val,reduced_expression_matrix[i,j])
     	}
      
      ####prediction of those genes (validationset) with estimated coefficients from learning set
      
      gr_predict_val <- c()
      
      for(j in id.gene.val){
        i = g
        g_pr <- paste(rownames(reduced_expression_matrix[i,]),j,sep="_")
        gr_predict_val <- c(gr_predict_val, g_pr)
      }
      
      prediction.vector <- c()
      
      for(j in id.gene.val){
        i = g
        
        es <- edgestrength_matrix[i,sort(id.tf)]
        act <- reduced_activity_matrix[sort(id.tf) ,j] 
        
        es.act <- as.numeric(es * act)
        
        vec1 <- as.numeric(c(es.act,1))
        vec2 <- beta.values_inner * vec1
        ex.predict <- sum(vec2)
        prediction.vector <- c(prediction.vector, ex.predict)
      }
      
      g_real_all <- c(g_real_all, g_real_val)
      prediction_all <- c(prediction_all, prediction.vector)
      
      result.table2 <- rbind(result.table2, c(paste(top_hits_inner, collapse=","),paste(beta.values_inner, collapse=";") ,
                                            o, cor(g_real_all, prediction_all, method="pearson")))
      
      }
      
	 result.table2=result.table2[-1,]
	 rownames(result.table2)=1:max_parameter_limit
	 result_complete_inner=c(result_complete_inner, list(result.table2))
	 
	########################## End inner CV ####################	
	
	bb=max(as.numeric(result.table2$correlation))
	bbb=which(result.table2$correlation==bb)
    
	best_tfs=result.table2$TF[bbb]
    best_tfs=unlist(strsplit(as.vector(best_tfs), ","))
    
    tf_vector_outer=best_tfs
    
    num_parameter_outer = 0
  	num_exp_parameter_outer = 0
  	num_cons_parameter_outer = 0
  	num_error_terms_outer = 0
  	parameter_limit_outer = 0
  
  	constraint_matrix_colnames_outer = c() 
  	exp_parameters_outer = c()
  
   	#b_bas
    num_parameter_outer = num_parameter_outer + 1
    constraint_matrix_colnames_outer = c(constraint_matrix_colnames_outer,b_bas) 

	#TFs
    target_gene_tf_index = which(colnames(edgestrength_matrix) %in% best_tfs)
      
      num_parameter_outer = num_parameter_outer + length(tf_vector_outer)
      num_exp_parameter_outer = num_exp_parameter_outer + length(tf_vector_outer)
      num_cons_parameter_outer = num_cons_parameter_outer + length(tf_vector_outer)
      
      #construct b_tf and x_tf variables
      for(i in 1:length(tf_vector_outer)){
        tf = tf_vector_outer[i]        
        b_tf_outer = paste("b_",tf,sep="")
        constraint_matrix_colnames_outer = c(constraint_matrix_colnames_outer,b_tf_outer)
     	exp_parameters_outer = c(exp_parameters_outer,b_tf_outer)
      }      
    
    if(num_exp_parameter_outer < max_parameter_limit){
    	parameter_limit_outer = num_exp_parameter_outer
    }else{
    	parameter_limit_outer = max_parameter_limit
    }
    
    current_model_matrix_colnames_outer = c(constraint_matrix_colnames_outer)
    
    #define error terms
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      sample_error_term = paste("e_",current_sample,sep="")
      current_model_matrix_colnames_outer = c(current_model_matrix_colnames_outer,sample_error_term)
    }
    num_error_terms_outer = length(current_model_samples)
   
   
   #############################################################
    #define number of constraints
    
    # 2 constraints for each sample (abs. value)
	num_constraints_outer = 2 * length(current_model_samples)    
    total_column_number = num_parameter_outer + num_error_terms_outer    
    
     #############################################################
    ###define model variables per iteration    
    #right-hand-side
    rhs = c()
    #objective vector
    obj = c()
    #fill with num_parameter x 0
    obj = c(obj,rep(0,total_column_number))
    #model sense
    modelsense = "min"
    #sense vector
    sense = c()
    #variable type
    vtype = c(rep("C",total_column_number))
    #"C" (continuous), "B" (binary), "I" (integer), "S" (semi-continuous), or "N" (semi-integer)
    #lower bound
    lb = c(rep(0,total_column_number))
    #upper bound
    ub = c(rep(0,total_column_number))
    #constraint matrix
    
    A <- matrix(0,nrow=num_constraints_outer,ncol=total_column_number,byrow=T)
    
    colnames(A) = current_model_matrix_colnames_outer
    names(obj) = current_model_matrix_colnames_outer
    names(lb) = current_model_matrix_colnames_outer
    names(ub) = current_model_matrix_colnames_outer
    names(vtype) = current_model_matrix_colnames_outer
   
    #iterate over samples and create sample constraints
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      #create error term
      sample_error_term = paste("e_",current_sample,sep="")
      sample_error_term_index = which(colnames(A) == sample_error_term)
      #add value to obj
      sample_error_obj_index = which(names(obj) == sample_error_term)
      obj[sample_error_obj_index] = 1
      
      #add lb
      sample_error_lb_index = which(names(lb) == sample_error_term)
      lb[sample_error_lb_index] = 0
      
      #add ub
      sample_error_ub_index = which(names(ub) == sample_error_term)
      ub[sample_error_ub_index] = big_m
      
      #sample expression value
      current_sample_expression_index = which(colnames(expression_matrix) == current_sample)
      current_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,current_sample_expression_index])
      #print(current_sample_expression_value)
      current_sample_expression_negative_value = -(current_sample_expression_value)
      #add expression values (+ and -) to rhs vector
      rhs = c(rhs,current_sample_expression_value,current_sample_expression_negative_value)
      #add sense for each expression vector
      sense = c(sense,"<=","<=")
      
      #b_bas
        #always 1
        #add to constraint_matrix
        A[((2*i)-1),b_bas] = 1
        A[(2*i),b_bas] = -1
        
        #add bounds
        lb[b_bas] = -big_m
        ub[b_bas] = big_m

      
      #TF
        if(length(tf_vector_outer) > 0){
          for(m in 1:length(tf_vector_outer)){
            tf = tf_vector_outer[m]
                        
            b_tf = paste(b_pre,tf,sep="")
            
            current_sample_tf_value = 0
            
            current_sample_tf_index = which(colnames(activity_matrix) == current_sample)
            if(length(current_sample_tf_index) > 0){
              current_tf_index = which(rownames(activity_matrix) == tf)
              if(!is.na(activity_matrix[current_tf_index,current_sample_tf_index])){
                current_sample_tf_value = as.numeric(activity_matrix[current_tf_index,current_sample_tf_index])*edgestrength_matrix[which(rownames(edgestrength_matrix)==target_gene),which(colnames(edgestrength_matrix) == tf)]
              }
            }           
            
            #add to constraint_matrix
            A[((2*i)-1),b_tf] = current_sample_tf_value
            A[(2*i),b_tf] = -current_sample_tf_value
            
            #add bounds          
            lb[b_tf] = -big_m
            ub[b_tf] = big_m
          }
        }      
      
	#add error terms
      A[((2*i)-1),sample_error_term_index] = -1
      A[(2*i),sample_error_term_index] = -1      
      
    }
    
	  current_result_parameter_index = which(result_parameter_matrix[,"parameter_limit"] == current_parameter_limit)
      
      model <- list()
      model$A          <- A
      model$obj        <- obj
      model$modelsense <- modelsense
      model$rhs        <- rhs
      model$sense      <- sense
      model$lb         <- lb
      model$ub         <- ub
      model$vtype      <- vtype
	     
      result <- gurobi(model, params)
      
      ################################################################
      #Evaluate single results
      
      result_var_vector = c()
      result_value_vector = c()
      
      #TF
      
        if(length(tf_vector_outer) > 0){
          for(m in 1:length(tf_vector_outer)){
            tf = tf_vector_outer[m]
            
            b_tf = paste(b_pre,tf,sep="")
            
            b_index = which(current_model_matrix_colnames_outer == b_tf)
            b_value = as.numeric(result$x[b_index])
            
              result_var_vector = c(result_var_vector,b_tf)
              result_value_vector = c(result_value_vector,b_value)
              parameter_index = which(colnames(result_parameter_matrix) == b_tf)      
              result_parameter_matrix[current_result_parameter_index,parameter_index] = b_value
          } 
        }           
     
    id.tf=which(colnames(ES) %in% tf_vector_outer) 
     
    v=rep(0, max_parameter_limit)
    
    if(o==1){
    result_parameter_matrix2=cbind(result_parameter_matrix, v)
    colnames(result_parameter_matrix2)[length(tf_vector)+2]="b_bas"
    result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    } else {result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    result_parameter_matrix2[o,1:(length(tf_vector)+1)]=result_parameter_matrix[o,]}
	     
    #######################################################################################################
	#Run Estimation of Prediction Performance:
	
	beta.values=result_parameter_matrix2[o,2:(length(tf_vector)+2)][result_parameter_matrix2[o,2:(length(tf_vector)+2)]!=0]
	
    X_val=expression_matrix[,colnames(expression_matrix) %in% current_predict_samples]
  	Act_val<-activity_matrix[,colnames(activity_matrix) %in% current_predict_samples]
    
    cell_line_name <- colnames(expression_matrix)
    id.cellline <- c(1:length(colnames(expression_matrix)))
    names(id.cellline) <- cell_line_name
    
    g_real_all <- c()
    prediction_all <- c()
    cor.vector <- c()

    id.gene.val <- id.cellline[names(id.cellline) %in% colnames(X_val)] 
    id.gene.test <- id.cellline[-(id.gene.val)]
  
  	g=which(rownames(edgestrength_matrix)==target_gene)     
  
    ###get real genexpression values for the remaining genes (validationset)
      g_real_val <- c()
     
      for(j in id.gene.val){
        i = g
       g_real_val <- c(g_real_val,expression_matrix[i,j])
     }
      
      ####prediction of those genes (validationset) with estimated coefficients from learning set
      
      gr_predict_val <- c()
      
      for(j in id.gene.val){
        i = g
        g_pr <- paste(rownames(expression_matrix[i,]),j,sep="_")
        gr_predict_val <- c(gr_predict_val, g_pr)
      }
      
      prediction.vector <- c()
      
      for(j in id.gene.val){
        i = g
        
        es <- edgestrength_matrix[i,sort(id.tf)]
        act <- activity_matrix[sort(id.tf) ,j] 
        
        es.act <- as.numeric(es * act)
        
        vec1 <- as.numeric(c(es.act,1))
        vec2 <- beta.values * vec1
        ex.predict <- sum(vec2)
        prediction.vector <- c(prediction.vector, ex.predict)
      }
      
      g_real_all <- c(g_real_all, g_real_val)
      prediction_all <- c(prediction_all, prediction.vector)
      
      pred[,o]=prediction_all
      result.table <- rbind(result.table, c(paste(tf_vector_outer, collapse=","),paste(beta.values, collapse=";") ,
                                            o, cor(g_real_all, prediction_all, method="pearson")))
      
      }
 pred[,(max_parameter_limit+1)]=g_real_all
 rownames(pred)=colnames(X_val)
 colnames(pred)=1:(max_parameter_limit+1)
 colnames(pred)[max_parameter_limit+1]="g_real"
 predictions=c(predictions, list(pred))

 result.table=result.table[-1,]
 rownames(result.table)=1:max_parameter_limit

 result_complete=c(result_complete, list(result.table))

############## Regulator Frequency #######
	regulators<-result.table$TF

	combined<-c()
	test=c()
	
  	for (ii in 1:parameter_limit){
    	t<-strsplit(as.vector(regulators[ii]), ",")
    	combined<-c(as.vector(combined),as.vector(t))
    	test=c(test, combined[[ii]])
    }
	gene<-as.matrix(table(test))
  	bla<-cbind(gene, gene[,1])
  	bla[,1]=rownames(bla)
  	colnames(bla)<-c("TFs", "Number")
  	tfs_vector=colnames(ES)[ES[target_gene,]>0]
	
	reg=as.data.frame(tfs_vector)
  	rownames(reg)=reg[,1]
	reg[,2]=rep(0,length(tf_vector))
  	rest=reg[!rownames(reg) %in% rownames(bla),]
  	blabla=rbind(bla, as.matrix(rest))

  	blabla<-blabla[order(blabla[,1], decreasing=FALSE),]
  	blabla=blabla[,-1]
	blabla=as.matrix(blabla)
	table_complete=cbind(table_complete, blabla)
 }}
 result=list(result_complete=result_complete, predictions=predictions, table_complete=table_complete, result_complete_inner=result_complete_inner)
 return(result)
}
