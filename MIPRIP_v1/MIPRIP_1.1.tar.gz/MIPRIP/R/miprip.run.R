miprip.run <-
function(group1, group2="Not defined", num_repeats, num_cv, num_parameter, inner_cv="FALSE", num_cv_inner, sample_size_group1=length(group1), sample_size_group2=length(group2), further_repeats_group1=1, further_repeats_group2=1){
	
 #### Testing the datasets ###
 
 #test if samples in expression matrix X and activity matrix Act are the same
 if(length(colnames(Act)) != length(colnames(X)) && length(colnames(X)[colnames(X) %in% colnames(Act)])!=length(colnames(Act))){
    print("Error: Number of samples provided in activity matrix and expression matrix differ")
    return()
  }
 
 if(length(setdiff(rownames(X),rownames(ES))) > 0.5){
    print(paste("Warning:",length(setdiff(rownames(X),rownames(ES))), "genes aren't contained in edgestrength matrix:",collapse = " "))
    print(paste(setdiff(rownames(X),rownames(ES)),collapse = ", "))
    X <- X[rownames(X) %in% rownames(ES),]
    ES <- ES[rownames(ES) %in% rownames(X),]
  }
  
  # test if set of TFs in edgestrength_matrix equals set of TFs in activity_matrix
  # if not error
  if(length(setdiff(rownames(Act),colnames(ES))) > 0.5){
    print(paste("Error:",length(setdiff(rownames(Act),colnames(ES))), " TFs aren't contained in edgestrength matrix:",collapse = " "))
    print(paste(setdiff(rownames(Act),colnames(ES)),collapse = ", "))
    return()
  }
  
  # same order of samples, genes and TFs in all data sets
  X=X[order(rownames(X), decreasing=FALSE),]
  X=X[,order(colnames(X), decreasing=FALSE)]
  
  ES=ES[order(rownames(ES), decreasing=FALSE),]
  ES=ES[,order(colnames(ES), decreasing=FALSE)]
  
  Act=Act[order(rownames(Act), decreasing=FALSE),]
  Act=Act[,order(colnames(Act), decreasing=FALSE)]
  
  Act <- Act[which(colSums(ES) > 0),]
  ES <- ES[,rownames(Act)]
  
 #########  Group1 ##########   
 #group=group1
 	cat("Modelling of group1", "\n")
 
	result_complete_group1=c()
	predictions_group1=c()
	frequency_group1=c()
	result_complete_inner_group1=c()
	
  	for (jj in 1:further_repeats_group1){
 		cat("Further Repeats Group1 ", jj, "\n")
	
		if(inner_cv==FALSE){
			results_group1=without_inner.run(group=group1, repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, sample_size=sample_size_group1)		
    	}else{
			 results_group1=inner.run(group=group1, repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, num_fold_cross_validation_inner=num_cv_inner, sample_size=sample_size_group1)  
    		 result_complete_inner_group1=c(result_complete_inner_group1, results_group1$result_complete_inner)
    	}
    	result_complete_group1=c(result_complete_group1, results_group1$result_complete)
    	predictions_group1=c(predictions_group1, results_group1$predictions)
    	frequency_group1=cbind(frequency_group1, results_group1$table_complete)
	}	
	
  	############### Group2 ##############
    if(group2=="Not defined"){
    	cat("Modelling finished", "\n")
    	
    	performance_group1=c()
    	for(aa in 1:(num_cv*num_repeats*further_repeats_group1)){
    		performance_group1=cbind(performance_group1, round(as.numeric(result_complete_group1[[aa]]$correlation), digits=2))
    		colnames(performance_group1)[aa]=aa
    		}
    	rownames(performance_group1)=1:num_parameter
    	
    		if(inner_cv==FALSE){
    		save(result_complete_group1, performance_group1, frequency_group1, predictions_group1, file=paste("MIPRIP_results_", target_gene, ".RData", sep=""))
    		}else{save(result_complete_group1, performance_group1, frequency_group1, predictions_group1, result_complete_inner_group1, file=paste("MIPRIP_results_", target_gene, ".RData", sep=""))
    		}
    		cat("Output written to ", paste("MIPRIP_results_", target_gene, ".RData", sep=""), "\n")
    	
    	#result=list(performance=performance_group1, frequency=frequency_group1)
		#return(result)
    }else{
   		 #group=group2
    
    	cat("Modelling of group2", "\n")
    
    	result_complete_group2=c()
		predictions_group2=c()
		frequency_group2=c()
		result_complete_inner_group2=c()
	
    	for (jj in 1:further_repeats_group2){
 			cat("Further Repeats Group2 ", jj, "\n")
    
			if(inner_cv==FALSE){	
    			results_group2=without_inner.run(group=group2, repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, sample_size=sample_size_group2)    				
    		}else{
		 		results_group2=inner.run(group=group2, repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, num_fold_cross_validation_inner=num_cv_inner, sample_size=sample_size_group2)   
    			result_complete_inner_group2=c(result_complete_inner_group2, results_group2$result_complete_inner)
    		}
    		result_complete_group2=c(result_complete_group2, results_group2$result_complete)
    		predictions_group2=c(predictions_group2, results_group2$predictions)
    		frequency_group2=cbind(frequency_group2, results_group2$table_complete)
    	}
		cat("Modelling finished", "\n")
	
		################ Significance Test ##########
	
		cat("Calculating Wilcoxon Text", "\n")
		tfs_vector=colnames(ES)[ES[target_gene,]>0]
		de_wil <-matrix(nrow=length(tfs_vector), ncol=3)

		sig=rownames(frequency_group1)

		dwii = 1
		for (ii in 1:length(sig)) {
	 		s=frequency_group1[rownames(frequency_group1)==sig[ii],]
	 		r=frequency_group2[rownames(frequency_group2)==sig[ii],]
         	this <- wilcox.test(as.numeric(s),as.numeric(r), paired = FALSE, alternative="greater");
         	de_wil[dwii,1]=sig[ii];
         	de_wil[dwii,2]=this$p.value;  
         	dwii = dwii + 1
		}

		de_wil[,3] = p.adjust(as.numeric(de_wil[,2]), method="BH"); 
		de_wil=de_wil[order(as.numeric(de_wil[,2])),]
		
		colnames(de_wil)=c("TF", "p-value", "p-value_BH")

		significant_hits=de_wil

		#de_wil=de_wil[de_wil[,3]<0.05,]
		
		cat("Significant Hits of ", target_gene, "\n")
		print(de_wil)
		
		####### Summary #####
		performance_group1=c()
    	for(aa in 1:(num_cv*num_repeats*further_repeats_group1)){
    		performance_group1=cbind(performance_group1, round(as.numeric(result_complete_group1[[aa]]$correlation), digits=2))
    		colnames(performance_group1)[aa]=aa
    		}
    	rownames(performance_group1)=1:num_parameter
    	
    	performance_group2=c()
    	for(aa in 1:(num_cv*num_repeats*further_repeats_group2)){
    		performance_group2=cbind(performance_group2, round(as.numeric(result_complete_group2[[aa]]$correlation), digits=2))
    		colnames(performance_group2)[aa]=aa
    		}
    	rownames(performance_group2)=1:num_parameter
    	
    	if(inner_cv==FALSE){
    		save(result_complete_group1, result_complete_group2, predictions_group1, predictions_group2, frequency_group1, frequency_group2, performance_group1, performance_group2, significant_hits, file=paste("MIPRIP_results_",target_gene,".RData", sep=""))
    	}else{
    		save(result_complete_group1, result_complete_group2, predictions_group1, predictions_group2, frequency_group1, frequency_group2, performance_group1, performance_group2, significant_hits, result_complete_inner_group1, result_complete_inner_group2, file=paste("MIPRIP_results_",target_gene,".RData", sep=""))
    	}
    	cat("Output written to ", paste("MIPRIP_results_", target_gene, ".RData", sep=""), "\n")
    	
		#result=list(Signif_hits=de_wil, result_group1=result_complete_group1, result_group2=result_complete_group2)
		#return(result)
  	}
}
