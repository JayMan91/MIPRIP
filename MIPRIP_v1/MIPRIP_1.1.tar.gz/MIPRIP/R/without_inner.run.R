without_inner.run <-
function(group, repeats, num_fold_cross_validation, max_parameter_limit, sample_size){
	
	samples_group=sample(group, sample_size, replace=FALSE)
	
	expression_matrix = X[,colnames(X) %in% samples_group]
	activity_matrix = Act[,colnames(Act) %in% samples_group]
	edgestrength_matrix = ES
	
	result_complete=c()
	result_complete_inner=c()
	predictions=c()
	table_complete=c()

	##### Options #####
	big_m = 1000

	b_bas = "b_bas"
	b_pre = "b_"
	x_pre = "x_"
	
	for (ll in 1:repeats){
	cat("Repeat", ll, "\n")
	
	########################## Sample set
	#select #num_sample_exclude samples randomly
	sample_pool = colnames(expression_matrix)
	num_sample_exclude = length(sample_pool) / num_fold_cross_validation
	num_sample_exclude = floor(num_sample_exclude)

	iteration_vector = c()
	sample_iteration_vector = c()

	iteration=0
	while(length(sample_pool) >= num_sample_exclude){
  		iteration = iteration + 1
  		iteration_vector = c(iteration_vector,iteration)
  
  		selected_samples = sample(sample_pool,num_sample_exclude, replace=FALSE)
  		selected_samples_term = paste(selected_samples, collapse = ",")
  		sample_iteration_vector = c(sample_iteration_vector,selected_samples_term)
  
  		selected_samples_index = which(sample_pool %in% selected_samples)
  		sample_pool = sample_pool[-selected_samples_index]  
	}

	iteration_sample_df = data.frame(iteration_vector,sample_iteration_vector)
	colnames(iteration_sample_df) = c("iteration","samples")
   
	#expression index
	target_gene_expression_index = which(rownames(expression_matrix) == target_gene)

 	#determine number of parameters
 	num_parameter = 0
  	num_exp_parameter = 0
  	num_cons_parameter = 0
  	num_error_terms = 0
  	parameter_limit = 0
  
  	constraint_matrix_colnames = c()
  	binary_parameters = c()  
  	exp_parameters = c()
  	tf_vector = c()
  
   	#b_bas
    num_parameter = num_parameter + 1
    constraint_matrix_colnames = c(constraint_matrix_colnames,b_bas) 

  	#TFs
    target_gene_tf_index = which(edgestrength_matrix[target_gene,] > 0)
    tf_vector = as.vector(colnames(edgestrength_matrix)[target_gene_tf_index])
      
      num_parameter = num_parameter + (2 * length(tf_vector))
      num_exp_parameter = num_exp_parameter + length(tf_vector)
      num_cons_parameter = num_cons_parameter + (2 * length(tf_vector))
      
      #construct b_tf and x_tf variables
      for(i in 1:length(tf_vector)){
        tf = tf_vector[i]        
        b_tf = paste("b_",tf,sep="")
        x_tf = paste("x_",tf,sep="")
        constraint_matrix_colnames = c(constraint_matrix_colnames,b_tf)
        constraint_matrix_colnames = c(constraint_matrix_colnames,x_tf)
        binary_parameters = c(binary_parameters,x_tf)
        exp_parameters = c(exp_parameters,b_tf)
      }      
    
      if(num_exp_parameter < max_parameter_limit){
   	 	parameter_limit = num_exp_parameter
  	  }else{
    	parameter_limit = max_parameter_limit
      }
  
  exp_parameter_occ = rep(0,length(exp_parameters))
  parameter_occurrende_df = data.frame(exp_parameters,exp_parameter_occ)
  colnames(parameter_occurrende_df) = c("parameter","occurrence")

  gene_cor_pred_df =  NULL

  total_cor_pred_list = list()
  total_cor_meas_list = list()

###########################################################################  
  
  #iterate over all samples sets for cross validation
	cat("Cross-validation", "\n")
	
	for(q in 1:length(rownames(iteration_sample_df))){
    current_cross_validation = q
    
    cat(current_cross_validation, "\n")
    
    result.table <- as.data.frame(cbind("TF"=1,"Betas_TF"=1,"Amount TF"=1, "correlation"=1))

    pred=matrix(nrow=num_sample_exclude, ncol=max_parameter_limit+1) 
        
    current_predict_sample_term = as.character(iteration_sample_df[q,2])
    current_predict_samples = as.vector(strsplit(current_predict_sample_term,",")[[1]])
    
    #get training samples
    training_samples_index = which(!colnames(expression_matrix) %in% current_predict_samples)
    training_samples = as.vector(colnames(expression_matrix)[training_samples_index])
    
    #construct global result matrix
    result_matrix_num_rows = parameter_limit
    result_matrix_num_cols = length(exp_parameters) + 1  
    result_parameter_matrix = matrix(0,result_matrix_num_rows,result_matrix_num_cols)
    colnames(result_parameter_matrix) = c("parameter_limit",exp_parameters)    
    parameter_limit_vector = as.vector(seq(1:parameter_limit))
    result_parameter_matrix[,"parameter_limit"] = parameter_limit_vector
    result_parameter_matrix = as.matrix(result_parameter_matrix)
    
    ###########################################################################  
    #set up model for all training samples
    
    current_model_samples = training_samples
    
    if (num_fold_cross_validation==1){
    current_model_samples=current_predict_samples
    }
    
    #determine which model samples have valid expression values
    current_model_sample_index = which(colnames(expression_matrix) %in% current_model_samples)
    reduced_expression_matrix = expression_matrix[,current_model_sample_index]
    
    current_model_sample_valid_expression_value_index = which(!is.na(reduced_expression_matrix[target_gene_expression_index,]))
    current_model_samples = as.vector(colnames(reduced_expression_matrix)[current_model_sample_valid_expression_value_index])    
    
    #############################################################
 
    current_model_matrix_colnames = c(constraint_matrix_colnames)
    
    #define error terms
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      sample_error_term = paste("e_",current_sample,sep="")
      current_model_matrix_colnames = c(current_model_matrix_colnames,sample_error_term)
    }
    num_error_terms = length(current_model_samples)
   
   #############################################################
    #define number of constraints
    # x_TF_1 + x_TF_2 + ... <= total_parameter_limit
    # b_TF - 1000 x_TF <= 0
    # b_TF + 1000 x_TF >= 0
    
    # 2 constraints for each sample (abs. value)
    # 1 for total parameter limit
        
    num_constraints = num_cons_parameter + (2 * length(current_model_samples)) + 1    
    total_column_number = num_parameter + num_error_terms    
    
     #############################################################
    ###define model variables per iteration    
    #right-hand-side
    rhs = c()
    #objective vector
    obj = c()
    #fill with num_parameter x 0
    obj = c(obj,rep(0,total_column_number))
    #model sense
    modelsense = "min"
    #sense vector
    sense = c()
    #variable type
    vtype = c(rep("C",total_column_number))
    #"C" (continuous), "B" (binary), "I" (integer), "S" (semi-continuous), or "N" (semi-integer)
    #lower bound
    lb = c(rep(0,total_column_number))
    #upper bound
    ub = c(rep(0,total_column_number))
    #constraint matrix
    
    A <- matrix(0,nrow=num_constraints,ncol=total_column_number,byrow=T)
    
    colnames(A) = current_model_matrix_colnames
    names(obj) = current_model_matrix_colnames
    names(lb) = current_model_matrix_colnames
    names(ub) = current_model_matrix_colnames
    names(vtype) = current_model_matrix_colnames
   
    #iterate over samples and create sample constraints
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      #create error term
      sample_error_term = paste("e_",current_sample,sep="")
      sample_error_term_index = which(colnames(A) == sample_error_term)
      #add value to obj
      sample_error_obj_index = which(names(obj) == sample_error_term)
      obj[sample_error_obj_index] = 1
      
      #add lb
      sample_error_lb_index = which(names(lb) == sample_error_term)
      lb[sample_error_lb_index] = 0
      
      #add ub
      sample_error_ub_index = which(names(ub) == sample_error_term)
      ub[sample_error_ub_index] = big_m
      
      #sample expression value
      current_sample_expression_index = which(colnames(expression_matrix) == current_sample)
      current_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,current_sample_expression_index])
      #print(current_sample_expression_value)
      current_sample_expression_negative_value = -(current_sample_expression_value)
      #add expression values (+ and -) to rhs vector
      rhs = c(rhs,current_sample_expression_value,current_sample_expression_negative_value)
      #add sense for each expression vector
      sense = c(sense,"<=","<=")
      
      #b_bas
        #always 1
        #add to constraint_matrix
        A[((2*i)-1),b_bas] = 1
        A[(2*i),b_bas] = -1
        
        #add bounds
        lb[b_bas] = -big_m
        ub[b_bas] = big_m
  
      #TF
        if(length(tf_vector) > 0){
          for(m in 1:length(tf_vector)){
            tf = tf_vector[m]
                        
            b_tf = paste(b_pre,tf,sep="")
            x_tf = paste(x_pre,tf,sep="")
            
            current_sample_tf_value = 0
            
            current_sample_tf_index = which(colnames(activity_matrix) == current_sample)
            if(length(current_sample_tf_index) > 0){
              current_tf_index = which(rownames(activity_matrix) == tf)
              if(!is.na(activity_matrix[current_tf_index,current_sample_tf_index])){
                current_sample_tf_value = as.numeric(activity_matrix[current_tf_index,current_sample_tf_index])*edgestrength_matrix[which(rownames(edgestrength_matrix)==target_gene),which(colnames(edgestrength_matrix) == tf)]
              }
            }           
            
            #add to constraint_matrix
            A[((2*i)-1),b_tf] = current_sample_tf_value
            A[(2*i),b_tf] = -current_sample_tf_value
            
            #add variable type                  
            vtype[x_tf] = "B"
            
            #add bounds          
            lb[b_tf] = -big_m
            ub[b_tf] = big_m
            
            lb[x_tf] = 0
            ub[x_tf] = 1
            
          }
        }      
      
	#add error terms
      A[((2*i)-1),sample_error_term_index] = -1
      A[(2*i),sample_error_term_index] = -1      
      
    }
    
    ###########################################################
    #determine current row_index
    current_row_index = (2 * length(current_model_samples)) + 1
    #add constraints
    
    #TF
      if(length(tf_vector) > 0){
        for(m in 1:length(tf_vector)){
          tf = tf_vector[m]
          
          b_tf = paste(b_pre,tf,sep="")
          x_tf = paste(x_pre,tf,sep="")
          
          #add 1 for exp parameter
          A[current_row_index,b_tf] = 1
          #add #big_m for binary parameter
          A[current_row_index,x_tf] = -big_m
          current_row_index = current_row_index + 1
          #repeat with minus sign
          A[current_row_index,b_tf] = 1
          A[current_row_index,x_tf] = big_m
          
          sense = c(sense,"<=",">=")
          rhs = c(rhs,0,0)
          
          current_row_index = current_row_index + 1
        } 
      }         
        
	#add constraint limit for all binary parameters
    for(k in 1:length(binary_parameters)){
      binary_parameter = binary_parameters[k]
      binary_parameter_index = which(colnames(A) == binary_parameter)
      A[current_row_index,binary_parameter_index] = 1
    }
    
    #add sense to last row for parameter_limit
    sense = c(sense,"<=")
        
    for(o in 1:parameter_limit){   
      current_parameter_limit = as.numeric(o)      
      current_result_parameter_index = which(result_parameter_matrix[,"parameter_limit"] == current_parameter_limit)
      #last constraint : sum of all binary variable <= parameter_limit
      #add current parameter_limit to rhs
      rhs[current_row_index] = current_parameter_limit
      
      model <- list()
      model$A          <- A
      model$obj        <- obj
      model$modelsense <- modelsense
      model$rhs        <- rhs
      model$sense      <- sense
      model$lb         <- lb
      model$ub         <- ub
      model$vtype      <- vtype
      
      #params <- list(timeLimit = 3600,ResultFile=file_name)
      #params <- list(timeLimit = 600,OutputFlag=0)      
      #params <- list(timeLimit = 600,OutputFlag=1)      
      result <- gurobi(model, params)
      
      ################################################################
      #Evaluate single results
      
      result_var_vector = c()
      result_value_vector = c()
      
      #find indices in current_model_matrix_colnames      
      
      #TF
      	top_hits=c()
      
        if(length(tf_vector) > 0){
          for(m in 1:length(tf_vector)){
            tf = tf_vector[m]
            
            b_tf = paste(b_pre,tf,sep="")
            x_tf = paste(x_pre,tf,sep="")
            
            b_index = which(current_model_matrix_colnames == b_tf)
            b_value = as.numeric(result$x[b_index])
            
        	x_index = which(current_model_matrix_colnames == x_tf)
            x_value = as.numeric(result$x[x_index])
            
            if(round(x_value,1) == 1){
              top_hits=c(top_hits, tf)
              result_var_vector = c(result_var_vector,b_tf)
              result_value_vector = c(result_value_vector,b_value)
              parameter_index = which(colnames(result_parameter_matrix) == b_tf)
              result_parameter_matrix[current_result_parameter_index,parameter_index] = b_value
            }
          } 
        }           
     
    id.tf=which(colnames(ES) %in% top_hits) 
     
    v=rep(0, max_parameter_limit)
    
    if(o==1){
    result_parameter_matrix2=cbind(result_parameter_matrix, v)
    colnames(result_parameter_matrix2)[length(tf_vector)+2]="b_bas"
    result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    } else {result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    result_parameter_matrix2[o,1:(length(tf_vector)+1)]=result_parameter_matrix[o,]}
	     
    #######################################################################################################
	#Run Estimation of Prediction Performance:
	
	beta.values=result_parameter_matrix2[o,2:(length(tf_vector)+2)][result_parameter_matrix2[o,2:(length(tf_vector)+2)]!=0]
	
    X_val=expression_matrix[,colnames(expression_matrix) %in% current_predict_samples]
  	Act_val<-activity_matrix[,colnames(activity_matrix) %in% current_predict_samples]
    
    cell_line_name <- colnames(expression_matrix)
    id.cellline <- c(1:length(colnames(expression_matrix)))
    names(id.cellline) <- cell_line_name
    
    g_real_all <- c()
    prediction_all <- c()
    cor.vector <- c()

    id.gene.val <- id.cellline[names(id.cellline) %in% colnames(X_val)] 
    id.gene.test <- id.cellline[-(id.gene.val)]
  
  	g=which(rownames(edgestrength_matrix)==target_gene)     
  
    ###get real genexpression values for the remaining genes (validationset)
      g_real_val <- c()
     
      for(j in id.gene.val){
        i = g
       g_real_val <- c(g_real_val,expression_matrix[i,j])
     }
      
      ####prediction of those genes (validationset) with estimated coefficients from learning set
      
      gr_predict_val <- c()
      
      for(j in id.gene.val){
        i = g
        g_pr <- paste(rownames(expression_matrix[i,]),j,sep="_")
        gr_predict_val <- c(gr_predict_val, g_pr)
      }
      
      prediction.vector <- c()
      
      for(j in id.gene.val){
        i = g
        
        es <- edgestrength_matrix[i,sort(id.tf)]
        act <- activity_matrix[sort(id.tf) ,j] 
        
        es.act <- as.numeric(es * act)
        
        vec1 <- as.numeric(c(es.act,1))
        vec2 <- beta.values * vec1
        ex.predict <- sum(vec2)
        prediction.vector <- c(prediction.vector, ex.predict)
      }
      
      g_real_all <- c(g_real_all, g_real_val)
      prediction_all <- c(prediction_all, prediction.vector)
      
      pred[,o]=prediction_all
      result.table <- rbind(result.table, c(paste(top_hits, collapse=","),paste(beta.values, collapse=";") ,
                                            o, cor(g_real_all, prediction_all, method="pearson")))
      
      }
	pred[,(max_parameter_limit+1)]=g_real_all
	rownames(pred)=colnames(X_val)
	colnames(pred)=1:(max_parameter_limit+1)
	colnames(pred)[max_parameter_limit+1]="g_real"
	predictions=c(predictions, list(pred))

	result.table=result.table[-1,]	
	rownames(result.table)=1:max_parameter_limit

	result_complete=c(result_complete, list(result.table))

############## Regulator Frequency #######
	regulators<-result.table$TF

	combined<-c()
	test=c()
	
  	for (ii in 1:parameter_limit){
    	t<-strsplit(as.vector(regulators[ii]), ",")
    	combined<-c(as.vector(combined),as.vector(t))
    	test=c(test, combined[[ii]])
    }
	gene<-as.matrix(table(test))
  	bla<-cbind(gene, gene[,1])
  	bla[,1]=rownames(bla)
  	colnames(bla)<-c("TFs", "Number")
  	tfs_vector=colnames(ES)[ES[target_gene,]>0]
	
	reg=as.data.frame(tfs_vector)
  	rownames(reg)=reg[,1]
	reg[,2]=rep(0,length(tf_vector))
  	rest=reg[!rownames(reg) %in% rownames(bla),]
  	blabla=rbind(bla, as.matrix(rest))

  	blabla<-blabla[order(blabla[,1], decreasing=FALSE),]
  	blabla=blabla[,-1]
	blabla=as.matrix(blabla)
	table_complete=cbind(table_complete, blabla)
 }}
 result=list(result_complete=result_complete, predictions=predictions, table_complete=table_complete)
 return(result)
}
